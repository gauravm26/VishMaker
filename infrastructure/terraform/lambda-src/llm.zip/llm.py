import json
import os

def handler(event, context):
    print("LLM Lambda invoked!")
    print(f"Event: {json.dumps(event)}")
    
    # In a real application, you would:
    # 1. Get the OpenAI API key from the OPENAI_API_KEY env var
    # 2. Use the OpenAI client to interact with the LLM
    # 3. Return the response from the LLM
    
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "message": "This is the LLM Lambda. OpenAI API calls would happen here."
        })
    } 